%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int temp_count = 0;
int label_count = 0;
FILE *tac_file;

char* newTemp() { char* t = malloc(10); sprintf(t, "t%d", temp_count++); return t; }
char* newLabel() { char* l = malloc(10); sprintf(l, "L%d", label_count++); return l; }

int yylex();
void yyerror(const char *s);
%}

%union { char* str; }

%token <str> ID NUM RELOP ARITHOP
%token WHILE IF ELSE FOR
%type <str> expr

/* Dangling Else Fix */
%nonassoc NO_ELSE
%nonassoc ELSE

/* Correct Operator Precedence (Math happens before Comparisons) */
%left RELOP
%left ARITHOP

%%
program : statement_list ;

statement_list : statement statement_list | statement ;

block : '{' statement_list '}' | statement ;

statement : ID '=' expr ';' { 
                fprintf(tac_file, "%s = %s\n", $1, $3); 
                printf("%s = %s\n", $1, $3);
            }
          | while_loop
          | if_stmt
          | for_loop
          ;

/* --- EXAM TIP: DELETE THE CONTROL FLOW BLOCKS BELOW THAT YOU DON'T NEED --- */

while_loop : WHILE '(' { 
                 char* l_start = newLabel(); 
                 fprintf(tac_file, "%s:\n", l_start); printf("%s:\n", l_start);
                 $<str>$ = l_start; 
             } 
             expr ')' { 
                 char* l_end = newLabel();
                 fprintf(tac_file, "ifFalse %s goto %s\n", $4, l_end); printf("ifFalse %s goto %s\n", $4, l_end);
                 $<str>$ = l_end; 
             } 
             block { 
                 fprintf(tac_file, "goto %s\n%s:\n", $<str>3, $<str>6); printf("goto %s\n%s:\n", $<str>3, $<str>6);
             }
           ;

if_stmt : IF '(' expr ')' {
              char* l_else = newLabel();
              fprintf(tac_file, "ifFalse %s goto %s\n", $3, l_else); printf("ifFalse %s goto %s\n", $3, l_else);
              $<str>$ = l_else;
          } 
          block {
              char* l_end = newLabel();
              fprintf(tac_file, "goto %s\n%s:\n", l_end, $<str>5); printf("goto %s\n%s:\n", l_end, $<str>5);
              $<str>$ = l_end;
          } 
          ELSE block {
              fprintf(tac_file, "%s:\n", $<str>7); printf("%s:\n", $<str>7);
          }
        | IF '(' expr ')' {
              char* l_end = newLabel();
              fprintf(tac_file, "ifFalse %s goto %s\n", $3, l_end); printf("ifFalse %s goto %s\n", $3, l_end);
              $<str>$ = l_end;
          }
          block %prec NO_ELSE {
              fprintf(tac_file, "%s:\n", $<str>5); printf("%s:\n", $<str>5);
          }
        ;

/* Standard C For-Loop translation: for(id = expr; expr; id = expr) */
for_loop : FOR '(' ID '=' expr ';' {
               fprintf(tac_file, "%s = %s\n", $3, $5); printf("%s = %s\n", $3, $5);
               char* l_start = newLabel();
               fprintf(tac_file, "%s:\n", l_start); printf("%s:\n", l_start);
               $<str>$ = l_start;
           }
           expr ';' {
               char* l_end = newLabel();
               fprintf(tac_file, "ifFalse %s goto %s\n", $8, l_end); printf("ifFalse %s goto %s\n", $8, l_end);
               $<str>$ = l_end;
           }
           ID '=' expr ')' block {
               fprintf(tac_file, "%s = %s\n", $11, $13); printf("%s = %s\n", $11, $13);
               fprintf(tac_file, "goto %s\n%s:\n", $<str>7, $<str>10); printf("goto %s\n%s:\n", $<str>7, $<str>10);
           }
         ;

/* ------------------------------------------------------------------------- */

expr : expr ARITHOP expr { 
         $$ = newTemp(); 
         fprintf(tac_file, "%s = %s %s %s\n", $$, $1, $2, $3); printf("%s = %s %s %s\n", $$, $1, $2, $3);
     }
     | expr RELOP expr { 
         $$ = newTemp(); 
         fprintf(tac_file, "%s = %s %s %s\n", $$, $1, $2, $3); printf("%s = %s %s %s\n", $$, $1, $2, $3);
     }
     | '(' expr ')'  { $$ = $2; }
     | ID  { $$ = $1; }
     | NUM { $$ = $1; }
     ;
%%

void yyerror(const char *s) { printf("Syntax Error\n"); }

int main() {
    extern FILE *yyin;
    yyin = fopen("input.c", "r");
    tac_file = fopen("tac.txt", "w");
    yyparse();
    fclose(yyin); fclose(tac_file);
    return 0;
}

// EXAM TIP: PRUNING parser.y
// - Make sure to delete unused Tokens at the top (%token IF ELSE FOR) if you delete their rules.
// - Make sure to delete them from the "statement : " OR list (e.g., delete "| if_stmt").
// - If the exam doesn't have if-else, DELETE the "%nonassoc NO_ELSE" and "%nonassoc ELSE" lines! They will cause errors if the IF/ELSE tokens are gone.